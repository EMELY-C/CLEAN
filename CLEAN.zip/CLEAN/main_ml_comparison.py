# -*- coding: utf-8 -*-
"""
Created on Fri Sep 25 15:18:44 2020

@author: Bing
"""
#%%
import spectrum_featurization as spefea
import maching_learning as machlea
import pandas as pd
import rdkit.Chem as Chem
import rdkit.Chem.AllChem as AllChem
from rdkit.ML.Descriptors import MoleculeDescriptors
from rdkit.Chem import Descriptors
import numpy as np
import math
from rdkit import DataStructs
from rdkit.Chem.Fingerprints import FingerprintMols
from rdkit.Chem.AtomPairs import Pairs
import matplotlib.pyplot as plt
import time
import sklearn
import keras
import tensorflow
import seaborn as sns
from tqdm import tqdm

#%%
# 输入文件
train_test=(pd.read_excel("/Users/zhangning/PycharmProjects/SVM-project/20241227/20241224_DNS&MPEA_train-test.xlsx"))
mols=list((train_test["SMILES"]))   # smiles 列表
fp_train_test=np.zeros(shape=(len(train_test),8034))    # 指纹全0np向量

# 获得cdk指纹
for i in range(len(train_test)):
    fp_train_test[i]=machlea.get_cdk_fingerprints(mols[i])
fp_0=fp_train_test.copy()

# 保留指纹位诧异率0.1-0.9之间的位点
fp_sum=[]
for i in range(8034):
    fp_num=0
    for j in range(len(train_test)):
        fp_num=fp_num+fp_train_test[j][i]
    fp_sum.append(fp_num)
index=[]
for i in range(8034):
    if(int(len(train_test)*0.1)<fp_sum[i]<int(len(train_test)*0.9)):
        index.append(i)
fp_train_test=fp_train_test[:,index]

# 删除共线性位点
index2=[0]
for i in range(len(index)):
    flag=1
    for j in range(len(index2)):
        if(list(fp_train_test[:,i])==list(fp_train_test[:,index2[j]])):
            flag=0
            break
    if(flag==1):
        index2.append(i)

# 得到特征位点
index3=[]
for i in index2:
    index3.append(index[i])
fp_train_test=fp_0[:,index3] 

print("清理train-test")
#creat fragment kernel matrix on train_test data
fr_train_test=np.zeros(shape=(len(train_test),len(train_test)))
fnr_train_test=np.zeros(shape=(len(train_test),len(train_test)))
frag_train_test=np.zeros(shape=(len(train_test),120000))


for i in tqdm(range(len(train_test)), desc="processing fnr_train_test"):
    for j in range(len(train_test)):
        fr_train_test[i][j]=spefea.FR(train_test["MSMS spectrum"][i],train_test["MSMS spectrum"][j],train_test["m/z"][i],train_test["m/z"][j])
        fnr_train_test[i][j]=spefea.FNR(train_test["MSMS spectrum"][i],train_test["MSMS spectrum"][j],train_test["m/z"][i],train_test["m/z"][j])

#%%
for i in range(len(train_test)):
    spe_i=spefea.MSMSpre1(train_test["MSMS spectrum"][i],train_test["m/z"][i],minmz=50,maxmz=2000)
    if(len(spe_i)==0):
        continue
    for j in range(len(spe_i)):
        mz_j=int(spe_i[j,0]*100-5000+0.5)
        frag_train_test[i][mz_j]=spe_i[j,1] 

#%%
#%%
# train the dataset using different spectrum featurization method using svm
df_fr_svm_linear=machlea.mach_lea(fr_train_test,fp_train_test,machlea.svm_linear)
df_fnr_svm_linear=machlea.mach_lea(fnr_train_test,fp_train_test,machlea.svm_linear)
df_frag_svm_linear=machlea.mach_lea(frag_train_test,fp_train_test,machlea.svm_linear)
df_shuffle_fnr_svm_linear=machlea.shuffle(fnr_train_test,fp_train_test,machlea.svm_linear)
df_fnr_svm_linear.to_csv("/Users/zhangning/PycharmProjects/Find_TPs/fnr_svm.csv", index=False)

# visualization results using violinplot
fig, axes = plt.subplots(nrows=2, ncols=2, figsize=(24, 16))
plt.violinplot
axes[0, 0].violinplot([ df_fr_svm_linear["acc"],df_fnr_svm_linear["acc"],df_frag_svm_linear["acc"], df_shuffle_fnr_svm_linear["acc"]], showmeans=False, showmedians=True)
axes[0, 1].violinplot([df_fr_svm_linear["pre"],df_fnr_svm_linear["pre"], df_frag_svm_linear["pre"],df_shuffle_fnr_svm_linear["pre"]], showmeans=False, showmedians=True)
axes[1, 0].violinplot([df_fr_svm_linear["rec"], df_fnr_svm_linear["rec"],df_frag_svm_linear["rec"], df_shuffle_fnr_svm_linear["rec"]], showmeans=False, showmedians=True)
axes[1, 1].violinplot([df_fr_svm_linear["f1"],df_fnr_svm_linear["f1"],df_frag_svm_linear["f1"], df_shuffle_fnr_svm_linear["f1"]], showmeans=False, showmedians=True)
font={"family":"Arial","weight":"normal","size":30}   
axes[0, 0].set_ylabel('Accuracy',font)
axes[0, 1].set_ylabel('Precision',font)
axes[1, 0].set_ylabel('Recall',font)
axes[1, 1].set_ylabel('F1 Score',font)
# plt.setp(axes, xticklabels=["","FR","",'FNR',"","Frag","","Random"])
xticklabels=["","FR","",'FNR',"","Frag","","Shu"]
yticklabel1=["","0.4","0.5","0.6","0.7","0.8","0.9","1.0"]
yticklabel2=["","0.0","0.2","0.4","0.6","0.8","1.0"]
axes[0, 0].set_xticklabels(xticklabels,fontproperties="Arial",size=30)
axes[0, 1].set_xticklabels(xticklabels,fontproperties="Arial",size=30)
axes[1, 0].set_xticklabels(xticklabels,fontproperties="Arial",size=30)
axes[1, 1].set_xticklabels(xticklabels,fontproperties="Arial",size=30)
axes[0, 0].set_yticklabels(yticklabel1,fontproperties="Arial",size=30)
axes[0, 1].set_yticklabels(yticklabel2,fontproperties="Arial",size=30)
axes[1, 0].set_yticklabels(yticklabel2,fontproperties="Arial",size=30)
axes[1, 1].set_yticklabels(yticklabel2,fontproperties="Arial",size=30)
plt.show()
#%%
# compare different maching learning algorithm
df_svm=machlea.mach_lea(fnr_train_test,fp_train_test,machlea.svm_linear)
df_logi=machlea.mach_lea(fnr_train_test,fp_train_test,machlea.logi)
df_bay=machlea.mach_lea(fnr_train_test,fp_train_test,machlea.bay)
df_dec=machlea.mach_lea(fnr_train_test,fp_train_test,machlea.dec)
df_ran=machlea.mach_lea(fnr_train_test,fp_train_test,machlea.ran)
df_knn=machlea.mach_lea(fnr_train_test,fp_train_test,machlea.knn5)
df_ann=machlea.mach_lea(fnr_train_test,fp_train_test,machlea.ann)
#%%
df_shuffle_fnr_svm_linear=machlea.shuffle(fnr_train_test,fp_train_test,machlea.svm_linear)
#%%
df_ann = pd.DataFrame(columns=['acc', 'pre', 'rec', 'f1'], data=np.zeros((1, 4)))
fig, axes = plt.subplots(nrows=2, ncols=2, figsize=(24, 16))
plt.violinplot

acc_=[0]
pre_=[0]
rec_=[0]
f1_=[0]
df_ann=(pd.DataFrame([acc_,pre_,rec_,f1_])).T
df_ann.columns=("acc","pre","rec","f1")

axes[0, 0].violinplot([df_svm["acc"], df_logi["acc"], df_bay["acc"], df_dec["acc"], df_ran["acc"], df_knn["acc"], df_ann["acc"], df_shuffle_fnr_svm_linear["acc"]], showmeans=False, showmedians=True)
axes[0, 1].violinplot([df_svm["pre"], df_logi["pre"],df_bay["pre"],df_dec["pre"],df_ran["pre"],df_knn["pre"],df_ann["pre"],df_shuffle_fnr_svm_linear["pre"]], showmeans=False, showmedians=True)
axes[1, 0].violinplot([df_svm["rec"], df_logi["rec"], df_bay["rec"], df_dec["rec"], df_ran["rec"], df_knn["rec"], df_ann["rec"], df_shuffle_fnr_svm_linear["rec"]], showmeans=False, showmedians=True)
axes[1, 1].violinplot([df_svm["f1"], df_logi["f1"], df_bay["f1"], df_dec["f1"], df_ran["f1"], df_knn["f1"], df_ann["f1"], df_shuffle_fnr_svm_linear["f1"]], showmeans=False, showmedians=True)
font={"family":"Arial","weight":"normal","size":30}
axes[0, 0].set_ylabel('Accuracy',font)
axes[0, 1].set_ylabel('Precision',font)
axes[1, 0].set_ylabel('Recall',font)
axes[1, 1].set_ylabel('F1 Score',font)
xticklabels=["",'SVM',"LOG","BAY","DEC","RAN","KNN","ANN","Shu"]
yticklabel1=["","0.4","0.5","0.6","0.7","0.8","0.9","1.0"]
yticklabel2=["","0.0","0.2","0.4","0.6","0.8","1.0"]
axes[0, 0].set_xticklabels(xticklabels,fontproperties="Arial",size=30)
axes[0, 1].set_xticklabels(xticklabels,fontproperties="Arial",size=30)
axes[1, 0].set_xticklabels(xticklabels,fontproperties="Arial",size=30)
axes[1, 1].set_xticklabels(xticklabels,fontproperties="Arial",size=30)
axes[0, 0].set_yticklabels(yticklabel1,fontproperties="Arial",size=30)
axes[0, 1].set_yticklabels(yticklabel2,fontproperties="Arial",size=30)
axes[1, 0].set_yticklabels(yticklabel2,fontproperties="Arial",size=30)
axes[1, 1].set_yticklabels(yticklabel2,fontproperties="Arial",size=30)
plt.show()
#%%
validation=pd.read_csv("validation.csv")
# return a list of top n and a list of formula/SMILES which is not found in pubchem
listtop=[]
listNA=[]
for i in range(len(validation)):
    print("validation progress",i,"of",len(validation))
    list_smiles=machlea.searchpubchem(validation["Formula"][i])
    if(list_smiles==None):
        listNA.append(validation["Formula"][i])
        continue
    for l in range(len(list_smiles)):
        list_smiles[l]=machlea.iso(list_smiles[l])
    list_smiles=list(set(list_smiles)) 
    if(validation["SMILES"][i] not in list_smiles):
        listNA.append(validation["SMILES"][i])
        continue
    fnr_=np.zeros(shape=(1,len(train_test)))
    for j in range(len(train_test)):
        fnr_[0][j]=spefea.FNR(train_test["MSMS spectrum"][j],validation["MSMS spectrum"][i],train_test["m/z"][j],validation["m/z"][i])
    fp_pre=np.zeros(shape=(1,fp_train_test.shape[1]))         
    for k in range(fp_train_test.shape[1]):
        fp_pre[0,k]=machlea.svm_(fnr_train_test,fp_train_test[:,k],fnr_)
    list_score=[]
    for m in range(len(list_smiles)):        
        fp_cac=np.array([machlea.get_cdk_fingerprints(list_smiles[m])])
        fp_cac=fp_cac[:,index3]
        score_=machlea.score(fp_pre,fp_cac,df_fnr_svm_linear)
        list_score.append(score_)
    print(list_score)
    df_fp=pd.DataFrame({"SMILES":list_smiles,"score":list_score})
    df_fp=df_fp.sort_values(by="score",ascending=False)    
    df_fp=df_fp.reset_index(drop=True)
    list_smiles2=list(df_fp["SMILES"])
    listtop.append(list_smiles2.index(validation["SMILES"][i])+1)
    
df_topn=pd.DataFrame({"SMILES":validation["SMILES"],"top":listtop})
top1=0
top3=0
top5=0
for i in listtop:
    if(i<6):
        top5+=1
        if(i<4):
            top3+=1
            if(i==1):
                top1+=1
print("The top1 rate is %.1f%%"%(top1/len(validation)*100),".",sep="")
print("The top3 rate is %.1f%%"%(top3/len(validation)*100),".",sep="")
print("The top5 rate is %.1f%%"%(top5/len(validation)*100),".",sep="")

#%%
import seaborn as sns
from tqdm import tqdm
validation = train_test
df_fnr_svm_linear = pd.read_csv("/Users/zhangning/PycharmProjects/SVM-project/20241227/fnr_knn.csv")
# 初始化 score 为一个矩阵，行数为 validation 的长度，列数为 list_smiles 的长度
list_smiles = validation["SMILES"].tolist()  # 数据库
list_val_name = validation["Name"].tolist()
list_name = validation["Name"].tolist()  # 数据库
num_validation = len(validation)
num_smiles = len(list_smiles)
list_score = np.zeros((num_validation, num_smiles))  # 创建一个零矩阵

for i in tqdm(range(num_validation), desc="Processing Features"):
    fnr_ = np.zeros(shape=(1, len(train_test)))

    # 计算 FNR
    for j in range(len(train_test)):
        fnr_[0][j] = spefea.FNR(train_test["MSMS spectrum"][j], validation["MSMS spectrum"][i],
                                train_test["m/z"][j], validation["m/z"][i])

    fp_pre = np.zeros(shape=(1, fp_train_test.shape[1]))

    # 使用 SVM 进行预测
    for k in range(fp_train_test.shape[1]):
        # fp_pre[0, k] = machlea.svm_(fnr_train_test, fp_train_test[:, k], fnr_)
        fp_pre[0, k] = knn_(fnr_train_test, fp_train_test[:, k], fnr_)

    for m in range(num_smiles):
        fp_cac = np.array([machlea.get_cdk_fingerprints(list_smiles[m])])
        fp_cac = fp_cac[:, index3]
        score_ = machlea.score(fp_pre, fp_cac, df_fnr_svm_linear)
        list_score[i, m] = score_  # 将分数存储到矩阵中

# 输出结果并保存到 Excel
df_fp = pd.DataFrame(list_score, columns=list_val_name)
# df_fp.insert(0, 'Name', list_name)
df_fp.index = [i for i in range(len(list_name))]  # 设置行索引为验证集索引
sum_f1 = df_fnr_svm_linear['f1'].sum()
df_fp = df_fp / sum_f1
df_fp.to_excel("热图数据.xlsx", index=False)  # 保存为 Excel
#%%
# 热图展示
# 读取 Excel 文件
df_score = df_fp

# 确保数据类型为 float
df_score = df_score.astype(float)

# 使用 seaborn 和 matplotlib 生成热图
plt.figure(figsize=(38, 35))

# 设置颜色映射为红到白
cmap = sns.color_palette("coolwarm", as_cmap=True)

# 生成热图
heatmap = sns.heatmap(df_score, annot=False, cmap=cmap, cbar=True, fmt=".2f",
                      annot_kws={"size": 8}, linewidths=.5, linecolor='gray', vmin=0, vmax=1)

# 移动标题到上方
plt.title('Tanimoto Coefficient Heatmap', fontsize=16, pad=20)

# 设置标签
plt.xlabel('Compounds', fontsize=15)
plt.ylabel('Compounds', fontsize=15)

# 获取当前的轴
ax = plt.gca()

# 调整x轴标签的位置，将其移动到上方
ax.xaxis.set_ticks_position('top')
ax.xaxis.set_label_position('top')

# 旋转x轴标签
plt.xticks(rotation=90)

# 设置纵坐标标签
labels = df_score.columns.tolist()  # 替换为你的标签
plt.yticks(ticks=range(len(labels)), labels=labels, rotation=0)  # 确保 ticks 与标签对应
plt.xticks(ticks=range(len(labels)), labels=labels)

# 设置坐标轴刻度的字体大小
plt.tick_params(axis='both', labelsize=7)  # 设置x轴和y轴的刻度字体大小

colorbar = heatmap.collections[0].colorbar
colorbar.ax.tick_params(labelsize=30)
# 显示图像
plt.show()

#%%
# train the dataset using different spectrum featurization method using svm
df_fr_knn_linear=machlea.mach_lea(fr_train_test,fp_train_test,machlea.knn5)
df_fnr_knn_linear=machlea.mach_lea(fnr_train_test,fp_train_test,machlea.knn5)
df_frag_knn_linear=machlea.mach_lea(frag_train_test,fp_train_test,machlea.knn5)
df_shuffle_fnr_knn_linear=machlea.shuffle(fnr_train_test,fp_train_test,machlea.knn5)
df_fnr_svm_linear.to_csv("/Users/zhangning/PycharmProjects/Find_TPs/fnr_svm.csv", index=False)

# visualization results using violinplot
fig, axes = plt.subplots(nrows=2, ncols=2, figsize=(24, 16))
plt.violinplot
axes[0, 0].violinplot([df_fr_knn_linear["acc"],df_fnr_knn_linear["acc"],df_frag_knn_linear["acc"], df_shuffle_fnr_knn_linear["acc"]], showmeans=False, showmedians=True)
axes[0, 1].violinplot([df_fr_knn_linear["pre"],df_fnr_knn_linear["pre"], df_frag_knn_linear["pre"],df_shuffle_fnr_knn_linear["pre"]], showmeans=False, showmedians=True)
axes[1, 0].violinplot([df_fr_knn_linear["rec"], df_fnr_knn_linear["rec"],df_frag_knn_linear["rec"], df_shuffle_fnr_knn_linear["rec"]], showmeans=False, showmedians=True)
axes[1, 1].violinplot([df_fr_knn_linear["f1"],df_fnr_knn_linear["f1"],df_frag_knn_linear["f1"], df_shuffle_fnr_knn_linear["f1"]], showmeans=False, showmedians=True)
font={"family":"Arial","weight":"normal","size":30}
axes[0, 0].set_ylabel('Accuracy',font)
axes[0, 1].set_ylabel('Precision',font)
axes[1, 0].set_ylabel('Recall',font)
axes[1, 1].set_ylabel('F1 Score',font)
# plt.setp(axes, xticklabels=["","FR","",'FNR',"","Frag","","Random"])
xticklabels=["","FR","",'FNR',"","Frag","","Shu"]
yticklabel1=["","0.4","0.5","0.6","0.7","0.8","0.9","1.0"]
yticklabel2=["","0.0","0.2","0.4","0.6","0.8","1.0"]
axes[0, 0].set_xticklabels(xticklabels,fontproperties="Arial",size=30)
axes[0, 1].set_xticklabels(xticklabels,fontproperties="Arial",size=30)
axes[1, 0].set_xticklabels(xticklabels,fontproperties="Arial",size=30)
axes[1, 1].set_xticklabels(xticklabels,fontproperties="Arial",size=30)
axes[0, 0].set_yticklabels(yticklabel1,fontproperties="Arial",size=30)
axes[0, 1].set_yticklabels(yticklabel2,fontproperties="Arial",size=30)
axes[1, 0].set_yticklabels(yticklabel2,fontproperties="Arial",size=30)
axes[1, 1].set_yticklabels(yticklabel2,fontproperties="Arial",size=30)
plt.show()

#%%
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
def knn_(X,y,hss):
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.25, random_state = 0)
    classifier = KNeighborsClassifier(n_neighbors=5)
    classifier.fit(X_train, y_train)
    return classifier.predict(hss)

#%%
import pandas as pd
import matplotlib.pyplot as plt

# 读取Excel文件的不同sheet
df_svm = pd.read_excel('/Users/zhangning/PycharmProjects/SVM-project/DNS&MPEA/多模型结果.xlsx', sheet_name='svm')
df_logi = pd.read_excel('/Users/zhangning/PycharmProjects/SVM-project/DNS&MPEA/多模型结果.xlsx', sheet_name='logi')
df_bay = pd.read_excel('/Users/zhangning/PycharmProjects/SVM-project/DNS&MPEA/多模型结果.xlsx', sheet_name='bay')
df_dec = pd.read_excel('/Users/zhangning/PycharmProjects/SVM-project/DNS&MPEA/多模型结果.xlsx', sheet_name='dec')
df_ran = pd.read_excel('/Users/zhangning/PycharmProjects/SVM-project/DNS&MPEA/多模型结果.xlsx', sheet_name='ran')
df_knn = pd.read_excel('/Users/zhangning/PycharmProjects/SVM-project/DNS&MPEA/多模型结果.xlsx', sheet_name='knn')

# 创建图形和子图
fig, axes = plt.subplots(nrows=1, ncols=1, figsize=(24, 24))

# 绘制小提琴图
axes.violinplot([df_svm["acc"], df_logi["acc"], df_bay["acc"], df_dec["acc"], df_ran["acc"], df_knn["acc"]],
                 showmeans=False, showmedians=True)

# 设置字体
font = {"family": "Arial", "weight": "normal", "size": 30}
axes.set_ylabel('Accuracy', font)

# 设置x轴标签和y轴刻度
xticklabels = ["", 'SVM', "LOG", "BAY", "DEC", "RAN", "KNN"]
yticklabel1 = ["", "0.4", "0.5", "0.6", "0.7", "0.8", "0.9", "1.0"]

axes.set_xticklabels(xticklabels, fontproperties="Arial", size=30)
axes.set_yticklabels(yticklabel1, fontproperties="Arial", size=30)

# 显示图形
plt.show()

